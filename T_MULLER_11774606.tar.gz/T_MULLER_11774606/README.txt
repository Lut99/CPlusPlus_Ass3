C++ ASSIGNMENT 3 - GAME OF LIFE
    by Tim Müller

De opdracht kan worden uitgevoerd door eerst de opdracht te compilen en dan te
runnen, of door direct uit te voeren vanuit make.

De eerste methode kan door eerst ```make``` of ```make main``` uit te voeren en
daarna ```./bin/main.out``` uit te voeren.

De tweede optie kan simpelweg door ```make run``` uit te voeren.

Het hoofdmenu van het programma kan worden genavigeerd door middel van
commando's, net zoals in een UNIX-terminal. Om te zien welke, kunt u 'help'
typen in elk van de menu's om een lijst met commando's en beschrijvingen ervan
te zien.

In het programma kunnen patterns worden geladen, die te vinden zijn onder de
"patterns/" map in de root. Het is daarom aan te randen om het programma vanaf
de root van de map uit te voeren.
